from simple_rest_client.resource import Resource


class CellAPI(Resource):
    actions = {
        "get_cells": {"method": "GET", "url": "/v1/cells"},
        "get_cells_next_page": {"method": "GET", "url": "/v1/cells"},
        "search_cells": {"method": "POST", "url": "/v1/cells", },
        "get_cell_by_id": {"method": "GET", "url": "/v1/cells/{}"},
        "get_co_sectors": {"method": "GET", "url": "/v1/cells/{}/cosectors"},
        "get_co_sites": {"method": "GET", "url": "/v1/cells/{}/cosites"},
        "get_neighbors": {"method": "GET", "url": "/v1/cells/{}/neighbors"}
    }


class ClustersAPI(Resource):
    actions = {
        "get_clusters": {"method": "GET", "url": "/v1/clusters"},
        "create_cluster": {"method": "POST", "url": "/v1/clusters", },
        "get_cluster_by_name": {"method": "GET", "url": "/v1/clusters/{}"},
        "delete_cluster_by_name": {"method": "DELETE", "url": "/v1/clusters/{}"},
        "get_cluster_cells": {"method": "GET", "url": "/v1/clusters/{}/cells"},
    }


class ControllersAPI(Resource):
    actions = {
        "get_controllers": {"method": "GET", "url": "/v1/controllers"},
        "get_controller_by_id": {"method": "GET", "url": "/v1/controllers/{}"},
        "get_controller_cells": {"method": "GET", "url": "/v1/controllers/{}/cells"},
        "get_controller_x2links": {"method": "GET", "url": "/v1/controllers/{}/x2links"},
    }


class MOsAPI(Resource):
    actions = {
        "find_mos": {"method": "POST", "url": "/v1/mos"},
        "get_mo_by_id": {"method": "GET", "url": "/v1/mos/{}", },
    }


class NeighborsAPI(Resource):
    actions = {
        "get_neighbors": {"method": "GET", "url": "/v1/neighbors"},
    }


class NetworkModelAPI(Resource):
    actions = {
        "get_network_model": {"method": "GET", "url": "/v1/networkmodel"},
        "get_network_model_keys": {"method": "GET", "url": "/v1/networkmodel/keys"},
        "create_network_model_keys": {"method": "POST", "url": "/v1/networkmodel/keys"},
        "get_network_model_key_by_id": {"method": "GET", "url": "/v1/networkmodel/keys/{}"},
        "delete_network_model_keys": {"method": "DELETE", "url": "/v1/networkmodel/keys"}
    }


class NeuralEngineAPI(Resource):
    actions = {
        "get_geo_candidates": {"method": "GET", "url": "/v1/neuralEngine/cells/{}/geoCandidates"},
        "get_geo_impact": {"method": "GET", "url": "/v1/neuralEngine/cells/{}/geoImpact"}
    }


class X2LinksAPI(Resource):
    actions = {
        "get_links": {"method": "POST", "url": "/v1/x2links"},
        "get_link_by_id": {"method": "GET", "url": "/v1/x2links/{}"}
    }
