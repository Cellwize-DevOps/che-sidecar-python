from simple_rest_client.api import API
import chime.naas.apis


class NaaSApi:
    api: API

    def __init__(
            self,
            api_root_url=None,
            timeout=None,
            headers=None,
            ssl_verify=None
    ):
        self.api = API(
            api_root_url=api_root_url,
            params={},
            headers=headers,
            timeout=timeout,
            append_slash=False,
            json_encode_body=True,
            ssl_verify=ssl_verify
        )

        self.api.add_resource(resource_name='cells', resource_class=chime.naas.apis.CellAPI)
        self.api.add_resource(resource_name='clusters', resource_class=chime.naas.apis.ClustersAPI)
        self.api.add_resource(resource_name='controllers', resource_class=chime.naas.apis.ControllersAPI)
        self.api.add_resource(resource_name='mos', resource_class=chime.naas.apis.MOsAPI)
        self.api.add_resource(resource_name='networkmodel', resource_class=chime.naas.apis.NetworkModelAPI)
        self.api.add_resource(resource_name='neighbors', resource_class=chime.naas.apis.NeighborsAPI)
        self.api.add_resource(resource_name='neural_engine', resource_class=chime.naas.apis.NeuralEngineAPI)
        self.api.add_resource(resource_name='x2links', resource_class=chime.naas.apis.X2LinksAPI)
