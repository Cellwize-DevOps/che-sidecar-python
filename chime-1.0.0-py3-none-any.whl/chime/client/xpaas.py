from simple_rest_client.api import API
import chime.xpaas.apis


class XPaaSApi:
    api: API

    def __init__(
            self,
            api_root_url=None,
            timeout=None,
            headers=None,
            ssl_verify=None,
    ):
        self.api = API(
            api_root_url=api_root_url,
            params={},
            headers=headers,
            timeout=timeout,
            append_slash=False,
            json_encode_body=True,
            ssl_verify=ssl_verify
        )

        self.api.add_resource(resource_name='counters', resource_class=chime.xpaas.apis.CountersAPI)
        self.api.add_resource(resource_name='kpis', resource_class=chime.xpaas.apis.KPIsAPI)
        self.api.add_resource(resource_name='histograms', resource_class=chime.xpaas.apis.HistogramsAPI)
        self.api.add_resource(resource_name='neighbors', resource_class=chime.xpaas.apis.NeighborsMetricsAPI)

