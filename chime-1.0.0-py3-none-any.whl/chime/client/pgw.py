from simple_rest_client.api import API
import chime.pgw.apis


class PGWApi:
    api: API

    def __init__(
            self,
            api_root_url=None,
            timeout=None,
            headers=None,
            ssl_verify=None
    ):

        self.api = API(
            api_root_url=api_root_url,
            params={},
            headers=headers,
            timeout=timeout,
            append_slash=False,
            json_encode_body=True,
            ssl_verify=ssl_verify
        )

        self.api.add_resource(resource_name='workorders', resource_class=chime.pgw.apis.WorkOrdersAPI)
        self.api.add_resource(resource_name='workitems', resource_class=chime.pgw.apis.WorkItemsAPI)
        self.api.add_resource(resource_name='oss', resource_class=chime.pgw.apis.OSSAPI)
        self.api.add_resource(resource_name='locks', resource_class=chime.pgw.apis.LockAPI)
