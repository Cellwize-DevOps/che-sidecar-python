from simple_rest_client.resource import Resource


class WorkOrdersAPI(Resource):
    actions = {
        "send_workorder": {"method": "POST", "url": "/v1/workOrders"},
        "get_workorders": {"method": "GET", "url": "/v1/workOrders", },
        "get_by_id": {"method": "GET", "url": "/v1/workOrders/{}"},
        "cancel": {"method": "POST", "url": "/v1/workOrders/cancel"},
        "rollback": {"method": "POST", "url": "/v1/workOrders/rollback"},
        "get_stream": {"method": "GET", "url": "/v1/workOrders/stream"}
    }


class WorkItemsAPI(Resource):
    actions = {
        "get_workitems": {"method": "GET", "url": "/v1/workItems"},
        "get_by_id": {"method": "GET", "url": "/v1/workItems/{}"},
        "cancel": {"method": "POST", "url": "/v1/workItems/cancel"},
        "rollback": {"method": "POST", "url": "/v1/workItems/rollback"},
        "get_workitem_types": {"method": "GET", "url": "/v1/workItems/types"}
    }


class OSSAPI(Resource):
    actions = {
        "get_oss": {"method": "GET", "url": "/v1/oss"},
        "get_maintenance_window": {"method": "GET", "url": "/v1/oss/{}/maintenance"},
        "configure_maintenance_window": {"method": "POST", "url": "/v1/oss/{}/maintenance"},
        "delete_maintenance_window": {"method": "DELETE", "url": "/v1/oss/{}/maintenance"},
        "get_timezones": {"method": "GET", "url": "/v1/oss/timeZones"}
    }


class LockAPI(Resource):
    actions = {
        "get_lock_by_is": {"method": "GET", "url": "/v1/locks/{}"},
        "create_lock_": {"method": "POST", "url": "/v1/locks"},
        "delete_lock": {"method": "DELETE", "url": "/v1/locks/{}"},
        "get_active_locks": {"method": "GET", "url": "/v1/locks/live"},
        "get_locks_log": {"method": "GET", "url": "/v1/locks/log"}
    }
