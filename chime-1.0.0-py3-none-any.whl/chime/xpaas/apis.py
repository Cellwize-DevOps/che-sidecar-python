from simple_rest_client.resource import Resource


class CountersAPI(Resource):
    actions = {
        "get_counters": {"method": "GET", "url": "/v1/counters"},
        "get_counters_data": {"method": "POST", "url": "/v1/counters/data"}
    }


class KPIsAPI(Resource):
    actions = {
        "get_kpis": {"method": "GET", "url": "/v1/kpis"},
        "create_kpi": {"method": "POST", "url": "/v1/kpis"},
        "get_kpi_by_name": {"method": "GET", "url": "/v1/kpis/{}"},
        "delete_kpi": {"method": "DELETE", "url": "/v1/kpis/{}"},
        "get_kpi_data": {"method": "POST", "url": "/v1/kpis/data"},
        "get_kpi_paged_data": {"method": "GET", "url": "/v1/kpis/data"}
    }


class HistogramsAPI(Resource):
    actions = {
        "get_histograms": {"method": "GET", "url": "/v1/histograms"},
        "get_histograms_data": {"method": "POST", "url": "/v1/histograms/data"}
    }


class NeighborsMetricsAPI(Resource):
    actions = {
        "get_neighbor_metrics": {"method": "GET", "url": "/v1/neighbors"},
        "get_neighbor_metrics_data": {"method": "POST", "url": "/v1/neighbors/data"}
    }
